# api.qunitjs.com

## Building and Deploying

We're using GitHub pages. Anything going to the gh-pages branch will be immediately published.

### Requirements

This is currenly tested using Jekyll and bundler gems from Ruby 2.4.1.1.

To setup for the first time:

```shell
gem install jekyll bundler
bundle install
```

To run it locally:

```shell
bundle exec jekyll serve
```
