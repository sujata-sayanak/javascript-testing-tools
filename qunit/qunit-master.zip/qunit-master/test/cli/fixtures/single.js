QUnit.module( "Single", function() {
	QUnit.test( "has a test", function( assert ) {
		assert.ok( true );
	} );
} );
