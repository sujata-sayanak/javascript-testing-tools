QUnit.test( "hanging", function( assert ) {
	assert.async();
} );
